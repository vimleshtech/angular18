import { Component, OnInit } from '@angular/core';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'app-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.css']
})
export class BodyComponent implements OnInit {

  name;
  price;
  quantity;
  total;

  li
  constructor() {
    this.name='Nitin Sinha';
    this.price=0;
    this.quantity=0;
    this.li =[]

   }

   takeName(event){

    this.name = event.target.value 

   }
   hello()
   {
     alert('test');

   }
   getprice(event){
    this.price=event.target.value 
   }
   getquantity(event){
    this.quantity=event.target.value 
  
   }
cal(){
  //var total=parseInt(document.getElementById("price").value*parseInt(document.getElementById("quantity").value);
  //alert("Total Amount=",total);
  this.total=this.price*this.quantity;
  //alert("the total is "+this.total)
  this.li.push({price:this.price,quantity:this.quantity})
  
}
  ngOnInit() {
  }

}
