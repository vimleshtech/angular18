import { Component } from '@angular/core';
//here @angular/core is inbuilt library/module

//@component : annotation 

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  

}
